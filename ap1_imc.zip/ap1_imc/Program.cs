﻿//Variavel para responder para escolha de encerrar ou continuar o programa
int resposta;
do
    //Perguntando as informações do usuario para começar o relatorio
    {
         Console.WriteLine("Informe o nome da pessoa:");
        string nome = Console.ReadLine();

        Console.WriteLine("Informe a idade da pessoa:");
        int idade = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Informe a altura (em metros):");
        double altura = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Informe o peso (em Kg):");
        double peso = Convert.ToDouble(Console.ReadLine());

    //varial criado para o calculo do IMC do usuario
        double IMC = peso / (altura * altura);

        //Estrutura de repetição para informar o IMC do usuario
        while (true)
        {
            if (IMC >= 0 && IMC <= 17.9)
            {
                Console.WriteLine($"Seu IMC é {IMC:F2}, você está abaixo do peso");
                break;
            }
            else if (IMC >= 18 && IMC <= 24.9)
            {
                Console.WriteLine($"Seu IMC é {IMC:F2}, seu peso está normal");
                break;
            }
            else if (IMC >= 25 && IMC <= 29.9)
            {
                Console.WriteLine($"Seu IMC é {IMC:F2}, você está com sobrepeso");
                 break;
            }
            else
            {
                Console.WriteLine($"Seu IMC é {IMC:F2}, você está com obesidade");
                break;
            }
        }
        //Estrutura de repetição para informar a faixa etária do usuario
        while (true)
        {
            if (idade >= 0 && idade <= 12)
            {
                Console.WriteLine($"Sua idade é {idade}, você é uma criança");
                break;
            }
            
            else if (idade >= 13 && idade <= 18)
            {
                Console.WriteLine($"Sua idade é {idade}, você é um adolescente");
                break;
            }

            else if (idade >= 19 && idade <= 59)
            {
                Console.WriteLine($"Sua idade é {idade}, você é um adulto");
                break;
            }

            else
            {
                Console.WriteLine($"Sua idade é {idade}, você é um idoso");
                break;
            }
        }
        //perguntando ao usuario se ele quer fazer outro relatorio
        Console.WriteLine("\nGostaria de gerar outro relatório: 1-SIM/0-NÃO");
        resposta = Convert.ToInt32(Console.ReadLine());
    //condição para o programa reiniciar caso digite "1"
    } while (resposta == 1);
